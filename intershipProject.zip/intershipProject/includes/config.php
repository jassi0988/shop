<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'dummy';
$config['db']['user'] = 'root';
$config['db']['pass'] = '';
$config['db']['pre'] = 'ad_';

$config['admin_folder'] = 'admin';
$config['version'] = '9.2';
$config['installed'] = '1';
?>